package common.model;

import java.io.Serializable;

public interface PartType
{
	public static final String LEG = "Leg";
	public static final String HAM = "Ham";
}
