/**
 * SlaughterhouseWebServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.6  Built on : Jul 30, 2017 (09:08:31 BST)
 */
package tier2.skeleton;

/**
 *  SlaughterhouseWebServiceSkeleton java skeleton for the axisService
 */
public class SlaughterhouseWebServiceSkeleton
    implements SlaughterhouseWebServiceSkeletonInterface {
    /**
     * Auto generated method signature
     *
     * @param registerAnimal0
     * @return
     */
    public void registerAnimal(tier2.RegisterAnimal registerAnimal0) {
        //TODO : fill this with the necessary business logic
    }

    /**
     * Auto generated method signature
     *
     * @param addPartToTrayType1
     * @return
     */
    public void addPartToTrayType(tier2.AddPartToTrayType addPartToTrayType1) {
        //TODO : fill this with the necessary business logic
    }

    /**
     * Auto generated method signature
     *
     * @param registerPackage2
     * @return
     */
    public void registerPackage(tier2.RegisterPackage registerPackage2) {
        //TODO : fill this with the necessary business logic
    }

    /**
     * Auto generated method signature
     *
     * @param getTraysForPacaking3
     * @return getTraysForPacakingResponse4
     */
    public tier2.GetTraysForPacakingResponse getTraysForPacaking(
        tier2.GetTraysForPacaking getTraysForPacaking3) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#getTraysForPacaking");
    }

    /**
     * Auto generated method signature
     *
     * @param getUncutAnimals5
     * @return getUncutAnimalsResponse6
     */
    public tier2.GetUncutAnimalsResponse getUncutAnimals(
        tier2.GetUncutAnimals getUncutAnimals5) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#getUncutAnimals");
    }
}
