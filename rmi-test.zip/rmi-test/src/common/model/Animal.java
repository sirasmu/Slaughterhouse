package common.model;

import java.io.Serializable;

public class Animal implements Serializable
{
	private String id;
	private double weight;
	
	public Animal(double weight)
	{
		id = SlaughterhouseUtilities.generateId();
		this.weight = weight;
	}
	
	public double getWeight()
	{
		return weight;
	}
	
	public String toString()
	{
		return "Animal: " + weight;
	}
}
