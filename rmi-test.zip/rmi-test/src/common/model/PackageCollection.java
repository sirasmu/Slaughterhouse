package common.model;

public class PackageCollection
{

}
