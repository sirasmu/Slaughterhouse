package Controller;
import java.util.ArrayList;

import view.View;
import model.*;


public class RegisterAnimalsController {

	View view;	
	AnimalCollection animals;
	TrayCollection traysHam;
	TrayCollection traysLeg;
	PackageCollection packages;
	
	public RegisterAnimalsController(){
		this.view = new View();
		this.animals= new AnimalCollection();
		this.traysHam= new TrayCollection();
		this.traysLeg= new TrayCollection();
		this.packages= new PackageCollection();
	}
	
	/*
	 * Split an animal when available in the registered animals list and put the parts 
	 * inside a tray (new tray or already created tray)
	 */
	public void splitAnimal(Animal animal)
	{
		if(animal.isAnimalSplit()){
		view.printLog("Animal already split!!");
		throw new Exception("Animal already split!!");
		}
			ArrayList<Integer> partsWeight=client.getPartsWeight();
			for(int i=0; i<partsWeight.size(); i++){
				if(i==0) 
				{
					/*Find and existing tray type of part that is not filled completely*/
					Tray temp1= traysHam.getAvailableTray(partsWeight.get(i), PartType.Ham);
					
					/*Add the extra weight to the tray and the animal reference*/
					temp1.addPartFromAnimal(animal, partsWeight.get(i));
				}
				else{
					/*Find and existing tray with type of part that is not filled completely*/
					Tray temp2= traysLeg.getAvailableTray(partsWeight.get(i), PartType.Leg);
					
					/*Add the extra weight to the tray and the animal reference*/
					temp2.addPartFromAnimal(animal, partsWeight.get(i));
				}
			}
		
		
	}
	
	
	/*
	 * Register a new animal
	 */
	public void registerAnimal(Animal animal){
		animals.add(animal);
		view.printLog("Animal registered: "+ animal.getId());
	}
	
	
	/*
	 * Register a new package
	 */
	public void registerPackage(Package pk){
		packages.add(pk);
	}
	
	
	
	
	
	
}
