package model;
import java.util.ArrayList;

public class PackageCollection
{
	private ArrayList<Package> packages;
	
	public PackageCollection()
	{
		packages = new ArrayList<>();
	}
	
	public void add(Package p)
	{
		packages.add(p);
	}
}

