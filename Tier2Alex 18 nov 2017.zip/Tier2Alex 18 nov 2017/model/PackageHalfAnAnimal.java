package model;

public class PackageHalfAnAnimal extends AbstractPackage
{	
	public PackageHalfAnAnimal(TrayCollection origins, PartType type)
	{
		super(origins);
	}
}
