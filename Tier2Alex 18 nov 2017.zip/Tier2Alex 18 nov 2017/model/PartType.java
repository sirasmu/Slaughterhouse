package model;

public enum PartType
{
	Leg, Ham
}
