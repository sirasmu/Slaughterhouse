/**
 * IWebServiceBadPackageSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.6  Built on : Jul 30, 2017 (09:08:31 BST)
 */
package webservice.skeleton;

/**
 *  IWebServiceBadPackageSkeletonInterface java skeleton interface for the axisService
 */
public interface IWebServiceBadPackageSkeletonInterface {
    /**
     * Auto generated method signature
     *
     * @param getBadPackages
     */
    public webservice.GetBadPackagesResponse getBadPackages(
        webservice.GetBadPackages getBadPackages);
}
