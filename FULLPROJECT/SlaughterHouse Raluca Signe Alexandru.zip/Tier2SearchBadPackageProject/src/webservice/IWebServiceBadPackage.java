package webservice;

public interface IWebServiceBadPackage {

	public String getBadPackages(String pk);
	
}
