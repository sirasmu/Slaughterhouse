package common;


public interface Config
{
//	public static final String TIER_2_SERVICE = "tier2";
	public static final String TIER_3_SERVICE = "tier3";
}
