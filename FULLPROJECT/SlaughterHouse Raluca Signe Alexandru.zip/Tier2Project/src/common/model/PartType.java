package common.model;

import java.io.Serializable;

public interface PartType
{
	public static final String LEG = "LEG";
	public static final String HAM = "HAM";
}
