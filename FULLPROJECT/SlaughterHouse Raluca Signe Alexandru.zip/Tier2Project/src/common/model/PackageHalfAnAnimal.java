package common.model;

import java.io.Serializable;

public class PackageHalfAnAnimal extends AbstractPackage implements Serializable
{	
	public PackageHalfAnAnimal(TrayCollection origins)
	{
		super(origins);
	}
}
