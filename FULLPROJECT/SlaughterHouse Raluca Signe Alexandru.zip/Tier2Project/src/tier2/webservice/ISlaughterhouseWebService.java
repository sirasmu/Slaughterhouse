package tier2.webservice;

public interface ISlaughterhouseWebService
{
	String readIncomingMessage(String message);
}
