/**
 * ISlaughterhouseWebServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.6  Built on : Jul 30, 2017 (09:08:31 BST)
 */
package tier2.webservice.skeleton;

/**
 *  ISlaughterhouseWebServiceSkeletonInterface java skeleton interface for the axisService
 */
public interface ISlaughterhouseWebServiceSkeletonInterface {
    /**
     * Auto generated method signature
     *
     * @param readIncomingMessage
     */
    public tier2.webservice.ReadIncomingMessageResponse readIncomingMessage(
        tier2.webservice.ReadIncomingMessage readIncomingMessage);
}
